#include <iostream>
#include <windows.h>
#include <clocale>
#include <iostream>

using namespace std;

class Point{
public:
	Point(int =0, int =0);
	int get_x() const;
	int get_y() const;
	void print() const;
private:
	int x, y;
};

Point::Point(int x, int y): x(x), y(y){
}

inline int Point::get_x()const{
	return x;
}

inline int Point::get_y()const{
	return y;
}

inline void Point::print() const{
	cout <<"x = "<< x << ", y = " << y << endl;
}

int main(){
	Point x;
	x.print();
    cout << endl;

	Point y(10);
	y.print();
	cout << endl;

	Point z(2, 4);
	z.print();
	return 0;
}
