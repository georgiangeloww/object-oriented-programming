#include <iostream>

using namespace std;

class Int{
	int n;
public:
	explicit Int(unsigned up){
		n=rand()%up;
	}
	Int(int n):n(n){}
	int getN(){return n;}
};

int main(){
	Int y=55u/2;
	cout<<y.getN()<<endl;

	Int z = 25u;
	cout<<z.getN()<<endl;

	return 0;
}
